package testwindow;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Dialog.ModalityType;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.Toolkit;

public class NewStu extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField textField_type;
	private JTextField textField_sno;
	private JTextField textField_name;
	private JTextField textField_sex;
	private JTextField textField_dept;

	/**
	 * Launch the application.
	 */
	public static void go() {
		try {
			NewStu dialog = new NewStu();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public NewStu() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(NewStu.class.getResource("/testwindow/bg.jpg")));
		setModalityType(ModalityType.APPLICATION_MODAL);
		setTitle("\u65B0\u5EFA\u5B66\u751F\u4FE1\u606F");
		setBounds(100, 100, 266, 267);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			textField_type = new JTextField();
			textField_type.setColumns(10);
			textField_type.setBounds(102, 127, 116, 21);
			contentPanel.add(textField_type);
		}
		{
			JLabel label = new JLabel("\u7528\u6237\u7C7B\u578B");
			label.setBounds(10, 130, 80, 15);
			contentPanel.add(label);
		}
		{
			JLabel label = new JLabel("\u5B66\u9662");
			label.setBounds(10, 99, 54, 15);
			contentPanel.add(label);
		}
		{
			JLabel label = new JLabel("\u6027\u522B");
			label.setBounds(10, 72, 82, 15);
			contentPanel.add(label);
		}
		{
			JLabel label = new JLabel("\u59D3\u540D");
			label.setBounds(12, 41, 54, 15);
			contentPanel.add(label);
		}
		{
			JLabel label = new JLabel("\u5B66\u53F7");
			label.setBounds(12, 13, 80, 15);
			contentPanel.add(label);
		}
		{
			textField_sno = new JTextField();
			textField_sno.setColumns(10);
			textField_sno.setBounds(102, 10, 116, 21);
			contentPanel.add(textField_sno);
		}
		{
			textField_name = new JTextField();
			textField_name.setColumns(10);
			textField_name.setBounds(102, 38, 116, 21);
			contentPanel.add(textField_name);
		}
		{
			textField_sex = new JTextField();
			textField_sex.setColumns(10);
			textField_sex.setBounds(102, 69, 116, 21);
			contentPanel.add(textField_sex);
		}
		{
			textField_dept = new JTextField();
			textField_dept.setColumns(10);
			textField_dept.setBounds(102, 96, 116, 21);
			contentPanel.add(textField_dept);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton button = new JButton("OK");
				button.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						String sql = "";
						sql = sql +"insert into student(sno,sname,sdept,ssex,type)"
								+ " values('"+textField_sno.getText().trim()+"'"
								+ ","+"'"+textField_name.getText().trim()+"'"
								+ "," + "'"+textField_dept.getText().trim()+"'"
								+ "," + "'"+textField_sex.getText().trim()+"'"
								+ "," + "'"+textField_type.getText().trim()+"')"
								;
						try {
							Statement st = Conn.dbconn.createStatement();
							st.executeQuery(sql);
							st.close();
							JOptionPane.showMessageDialog(button, "�ύ�ɹ���", "��ʾ", JOptionPane.WARNING_MESSAGE);
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
							if(e1.getErrorCode() == 0)
							JOptionPane.showMessageDialog(button, "�ύ�ɹ���", "��ʾ", JOptionPane.WARNING_MESSAGE);
							else
							JOptionPane.showMessageDialog(button, "�ύʧ�ܣ�", "��ʾ", JOptionPane.WARNING_MESSAGE);
						}
					}
				});
				button.setActionCommand("OK");
				buttonPane.add(button);
				getRootPane().setDefaultButton(button);
			}
		}
	}

}
