package testwindow;

import java.awt.Color;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.*;
import java.awt.Toolkit;


public class Student {

	public JFrame frame;
	private JTextField textField_name;
	private JTextField textField_sno;
	private JTextField textField_type;
	private JTextField textField_dept;
	private JButton button_new;
	private JButton button_mod;
	private JTextField textField_sex;
	public static Student win;
	private JButton button_del;
	private JTextField textField_date;
	private JTextField textField_time;
	private JTextField textField_fee;
	private JTextField textField_status;
	private boolean status = false;
	private JTextField textField_cno;
	/**
	 * Launch the application.
	 */
	public static void go() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Student window = new Student();
					win = window;
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Student() {
		initialize();
	}
	
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage(Student.class.getResource("/testwindow/bg.jpg")));
		frame.setTitle("\u5B66\u751F\u7BA1\u7406");
		frame.setBounds(100, 100, 489, 411);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				FuncSelect.frame.setVisible(true);
			}
		});
		
		textField_date = new JTextField("");
		textField_date.setEditable(false);
		textField_date.setBounds(259, 62, 80, 21);
		frame.getContentPane().add(textField_date);
		textField_date.setColumns(10);
		
		textField_time = new JTextField("");
		textField_time.setEditable(false);
		textField_time.setBounds(366, 62, 97, 21);
		frame.getContentPane().add(textField_time);
		textField_time.setColumns(10);
		
		textField_sno = new JTextField();
		textField_sno.setEditable(false);
		textField_sno.setBounds(94, 94, 116, 21);
		frame.getContentPane().add(textField_sno);
		textField_sno.setColumns(10);
		
		textField_type = new JTextField();
		textField_type.setEditable(false);
		textField_type.setBounds(94, 183, 116, 21);
		frame.getContentPane().add(textField_type);
		textField_type.setColumns(10);
		
		textField_name = new JTextField();
		textField_name.setBounds(94, 28, 116, 21);
		frame.getContentPane().add(textField_name);
		textField_name.setColumns(10);
		
		JLabel label_2 = new JLabel("\u8D39\u7528");
		label_2.setBounds(259, 186, 54, 15);
		frame.getContentPane().add(label_2);
		
		textField_fee = new JTextField();
		textField_fee.setEditable(false);
		textField_fee.setBounds(259, 215, 93, 21);
		frame.getContentPane().add(textField_fee);
		textField_fee.setColumns(10);
		
		textField_status = new JTextField();
		textField_status.setEditable(false);
		textField_status.setBounds(366, 93, 54, 21);
		frame.getContentPane().add(textField_status);
		textField_status.setColumns(10);
		
		JLabel label_3 = new JLabel("\u5143");
		label_3.setBounds(366, 218, 54, 15);
		frame.getContentPane().add(label_3);
		

		JLabel lblName = new JLabel("\u59D3\u540D");
		lblName.setBounds(2, 31, 54, 15);
		frame.getContentPane().add(lblName);
		
		
		
		JLabel lblStudentNumber = new JLabel("\u5B66\u53F7");
		lblStudentNumber.setBounds(2, 97, 80, 15);
		frame.getContentPane().add(lblStudentNumber);
		
		JLabel lblGender = new JLabel("\u6027\u522B");
		lblGender.setBounds(2, 122, 82, 15);
		frame.getContentPane().add(lblGender);
		
		textField_dept = new JTextField();
		textField_dept.setEditable(false);
		textField_dept.setBounds(94, 152, 116, 21);
		frame.getContentPane().add(textField_dept);
		textField_dept.setColumns(10);
		
		JLabel lblUserType = new JLabel("\u7528\u6237\u7C7B\u578B");
		lblUserType.setBounds(2, 186, 80, 15);
		frame.getContentPane().add(lblUserType);
		
		button_new = new JButton("\u65B0\u5EFA");
		button_new.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				NewStu.go();
				
			}
		});
		button_new.setBounds(117, 214, 93, 23);
		frame.getContentPane().add(button_new);
		
		button_mod = new JButton("\u4FEE\u6539");
		button_mod.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				ModStu.go();
				
			}
		});
		button_mod.setBounds(117, 247, 93, 23);
		frame.getContentPane().add(button_mod);
		
		JLabel label = new JLabel("\u5B66\u9662");
		label.setBounds(2, 155, 54, 15);
		frame.getContentPane().add(label);
		
		textField_sex = new JTextField();
		textField_sex.setEditable(false);
		textField_sex.setBounds(94, 125, 116, 21);
		frame.getContentPane().add(textField_sex);
		textField_sex.setColumns(10);
		
		button_del = new JButton("\u5220\u9664");
		button_del.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					String sql = "delete from student where sno = '"+textField_sno.getText().trim()+"'";
					Statement st = Conn.dbconn.createStatement();
					st.executeQuery(sql);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					if(e1.getErrorCode() == 0)
						JOptionPane.showMessageDialog(button_del, "ɾ���ɹ�", "��ʾ", JOptionPane.INFORMATION_MESSAGE);
					else
						JOptionPane.showMessageDialog(button_del, "ɾ���ɹ�", "��ʾ", JOptionPane.ERROR_MESSAGE);
					e1.printStackTrace();
				}
			}
		});
		button_del.setBounds(117, 280, 93, 23);
		frame.getContentPane().add(button_del);
		
		JButton button_online = new JButton("\u4E0A\u673A");
		button_online.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(!status) {
					try {
						
						Statement st = Conn.dbconn.createStatement();
						ResultSet rs2 = st.executeQuery("select rno from computer where cno = '"+textField_cno.getText().trim()+"'");
						String rno = "";
						while(rs2.next()) {
							rno = rs2.getString("rno").trim();
						}
						
						st.execute("insert into record(rno,cno,sno,st,et,fee) values("
								+ "'"+rno+"'"
								+ ",'"+textField_cno.getText().trim()+"'"
								+ ",'"+textField_sno.getText().trim()+"'"
								+ ",getdate()"
								+ ",null"
								+ ",null)");
						textField_status.setBackground(Color.green);
						status = true;
						JOptionPane.showMessageDialog(button_online, "���߳ɹ���", "��ʾ", JOptionPane.INFORMATION_MESSAGE);
						ResultSet rs = st.executeQuery("select max(st) as st from record where sno = '"+textField_sno.getText().trim()+"'");
						rs.next();
						textField_date.setText(rs.getDate("st").toString());
						textField_time.setText(rs.getTime("st").toString());
						rs.close();
						st.close();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						JOptionPane.showMessageDialog(button_online, "����ʧ�ܣ�", "��ʾ", JOptionPane.ERROR_MESSAGE);
						e1.printStackTrace();
					}
					
				}
			}
		});
		button_online.setBounds(259, 153, 93, 23);
		frame.getContentPane().add(button_online);
		
		JButton button_offline = new JButton("\u4E0B\u673A");
		button_offline.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(status) {
					
					try {
						Statement st = Conn.dbconn.createStatement();
						String starttime = "";
						ResultSet rs = st.executeQuery("select max(st) as st from record where sno = '"+textField_sno.getText().trim()+"'");
						while(rs.next()) {
							starttime = rs.getString("st").trim();
						}
						rs.close();
						st.execute("update record set et = getdate() where st = '"+starttime.trim()+"'");
						ResultSet rs2 = st.executeQuery("select fee from record where st = '"+starttime.trim()+"'"); 
						while(rs2.next()) {
							textField_fee.setText(rs2.getString("fee"));
						}
						rs2.close();
						textField_status.setBackground(Color.red);
						status = false;
						JOptionPane.showMessageDialog(button_offline, "�»��ɹ���", "��ʾ", JOptionPane.INFORMATION_MESSAGE);
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						JOptionPane.showMessageDialog(button_offline, "�»�ʧ�ܣ�", "��ʾ", JOptionPane.ERROR_MESSAGE);
						e1.printStackTrace();
					}
					
				}
			}
		});
		button_offline.setBounds(366, 153, 93, 23);
		frame.getContentPane().add(button_offline);
		
		JLabel label_1 = new JLabel("\u6700\u540E\u4E00\u6B21\u4E0A\u673A\u8BB0\u5F55");
		label_1.setBounds(259, 10, 116, 15);
		frame.getContentPane().add(label_1);
		
		
		JButton btnNewButton = new JButton("\u67E5\u8BE2");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
					try {
						Statement st = Conn.dbconn.createStatement();
						ResultSet rs = st.executeQuery(""
								+ "select * "
								+ "from student "
								+ "where sname ='"+textField_name.getText().trim()+"'");
							while(rs.next()) {
								if(rs.getString("sno") == null || rs.getString("sno").equals(""))
									throw new Exception();
								else {
							textField_sno.setText(rs.getString("sno"));
							textField_type.setText(rs.getString("type"));
							textField_name.setText(rs.getString("sname"));
							textField_dept.setText(rs.getString("Sdept"));
							textField_sex.setText(rs.getString("ssex"));
							}
								}
						ResultSet rs2 = st.executeQuery("select max(st) as st from record where sno = '"+textField_sno.getText().trim()+"'");
						String datetime="";
						while(rs2.next()) {
						if(rs2.getString("st") == null) {
							status = false;
							JOptionPane.showMessageDialog(btnNewButton, "û���ϻ���¼��", "��ʾ", JOptionPane.INFORMATION_MESSAGE);
							textField_status.setBackground(Color.red);
							textField_cno.setText("");
							textField_date.setText("");
							textField_time.setText("");
						}
						else {
						datetime =  rs2.getString("st");
						textField_date.setText(rs2.getDate("st").toString());
						textField_time.setText(rs2.getTime("st").toString());
						}
						}
						rs2.close();
						ResultSet rs3 = st.executeQuery("select et,cno from record where st = '"+datetime.trim()+"'");
						while(rs3.next()) {
							textField_cno.setText(rs3.getString("cno"));
							if(rs3.getString("et") == null) {
								textField_status.setBackground(Color.GREEN);
								status = true;
							}
							else {
								textField_status.setBackground(Color.RED);
								status = false;
							}
						}
					}catch(Exception exc) {
						exc.printStackTrace();
						JOptionPane.showMessageDialog(btnNewButton, "���޴��ˣ�", "��ʾ", JOptionPane.ERROR_MESSAGE);
					}
				
			}
		});
		btnNewButton.setBounds(117, 61, 93, 23);
		frame.getContentPane().add(btnNewButton);
		
		JLabel label_4 = new JLabel("\u65E5\u671F");
		label_4.setBounds(259, 37, 54, 15);
		frame.getContentPane().add(label_4);
		
		JLabel label_5 = new JLabel("\u65F6\u95F4");
		label_5.setBounds(383, 37, 54, 15);
		frame.getContentPane().add(label_5);
		
		
		
		JLabel label_6 = new JLabel("\u72B6\u6001");
		label_6.setBounds(285, 97, 54, 15);
		frame.getContentPane().add(label_6);
		
		textField_cno = new JTextField();
		textField_cno.setBounds(366, 125, 97, 21);
		frame.getContentPane().add(textField_cno);
		textField_cno.setColumns(10);
		
		JLabel label_7 = new JLabel("\u673A\u53F7");
		label_7.setBounds(285, 128, 54, 15);
		frame.getContentPane().add(label_7);
	}
	
	JTextField getTextField_name() {
		return textField_name;
	}

	void setTextField_name(JTextField textField_name) {
		this.textField_name = textField_name;
	}

	JTextField getTextField_sno() {
		return textField_sno;
	}

	void setTextField_sno(JTextField textField_sno) {
		this.textField_sno = textField_sno;
	}

	JTextField getTextField_type() {
		return textField_type;
	}

	void setTextField_type(JTextField textField_type) {
		this.textField_type = textField_type;
	}

	JTextField getTextField_dept() {
		return textField_dept;
	}

	void setTextField_dept(JTextField textField_dept) {
		this.textField_dept = textField_dept;
	}

	JTextField getTextField_sex() {
		return textField_sex;
	}

	void setTextField_sex(JTextField textField_sex) {
		this.textField_sex = textField_sex;
	}
}
