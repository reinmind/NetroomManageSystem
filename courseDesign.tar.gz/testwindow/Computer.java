package testwindow;

import java.awt.EventQueue;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.JFrame;
import java.awt.Toolkit;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JOptionPane;

import java.sql.*;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.event.ListSelectionListener;

import testwindow.comop.NewCom;
import testwindow.comop.ModCom;

import javax.swing.event.ListSelectionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;
public class Computer {

	private JFrame frame;
	private JTextField textField_room_location;
	private JTextField textField_room_num;
	private JTextField textField_ip;
	private JTextField textField_income;
	public static String cno="";
	public static String rno="";
	public static Computer com;
	/**
	 * Create the application.
	 */
	public Computer() {
		initialize();
	}
	
	public static void go() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Computer window = new Computer();
					com = window;
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage(Computer.class.getResource("/testwindow/bg.jpg")));
		frame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
			FuncSelect.frame.setVisible(true);
			}
		});
		frame.setTitle("\u673A\u623F\u7BA1\u7406");
		frame.setBounds(100, 100, 501, 442);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel label = new JLabel("\u673A\u623F\u5217\u8868");
		label.setBounds(10, 26, 54, 15);
		frame.getContentPane().add(label);
		Vector<String> v_room = new Vector<>();
		try {
			String sql = "select rno from room";
			Statement st = Conn.dbconn.createStatement();
			ResultSet rs = st.executeQuery(sql);
			while(rs.next()) {
				v_room.add(rs.getString("rno"));
			}
			rs.close();
			st.close();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		textField_ip = new JTextField();
		textField_ip.setEditable(false);
		textField_ip.setBounds(211, 269, 132, 21);
		frame.getContentPane().add(textField_ip);
		textField_ip.setColumns(10);
		
		textField_income = new JTextField();
		textField_income.setEditable(false);
		textField_income.setBounds(10, 372, 137, 21);
		frame.getContentPane().add(textField_income);
		textField_income.setColumns(10);
		
		JLabel label_1 = new JLabel("\u673A\u623F\u5730\u5740");
		label_1.setBounds(10, 252, 54, 15);
		frame.getContentPane().add(label_1);
		
		textField_room_location = new JTextField();
		textField_room_location.setEditable(false);
		textField_room_location.setBounds(10, 269, 137, 21);
		frame.getContentPane().add(textField_room_location);
		textField_room_location.setColumns(10);
		
		JLabel label_2 = new JLabel("\u673A\u5668\u5217\u8868");
		label_2.setBounds(211, 26, 54, 15);
		frame.getContentPane().add(label_2);
		
		JPanel panel_computer = new JPanel();
		panel_computer.setBounds(211, 63, 111, 171);
		frame.getContentPane().add(panel_computer);
		Vector<String> v_computer = new Vector<>();
		v_computer.add("null");
		JList list_computer = new JList(v_computer);
		list_computer.addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent e) {
				cno = (String)list_computer.getSelectedValue();
				try {
					Statement st = Conn.dbconn.createStatement();
					ResultSet rs = st.executeQuery("select ip from computer where cno = '"+cno+"'");
					while(rs.next()) {
						textField_ip.setText(rs.getString("ip").trim());
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		list_computer.setVisibleRowCount(10);
		
		JScrollPane scrollPane_computer = new JScrollPane(list_computer);
		scrollPane_computer.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		panel_computer.add(scrollPane_computer);
		
		
		textField_room_num = new JTextField();
		textField_room_num.setEditable(false);
		textField_room_num.setBounds(10, 325, 137, 21);
		frame.getContentPane().add(textField_room_num);
		textField_room_num.setColumns(10);
		
		JList list_room = new JList(v_room);
		list_room.addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent e) {
				int index = list_room.getSelectedIndex();
				rno = v_room.elementAt(index);
				try {
					Statement st = Conn.dbconn.createStatement();
					ResultSet rs = st.executeQuery("select cno from computer where rno = '"+rno+"'");
					v_computer.clear();
					while(rs.next()) {
						v_computer.add(rs.getString("cno"));
					}
					rs.close();
					list_computer.setListData(v_computer);
					ResultSet rs3 = st.executeQuery("select count(*) as num from computer where rno = '"+rno+"'");
					String num="";
					while(rs3.next()) {
						num = rs3.getString("num");
					}
					textField_room_num.setText(num);
					st.execute("update room set num ="+num);
					rs3.close();
					ResultSet rs1 = st.executeQuery("select location from room where rno = '"+rno+"'");
					while(rs1.next()) {
						textField_room_location.setText(rs1.getString("location"));
					}
					rs1.close();
					ResultSet rs4 = st.executeQuery("select sum(fee) as income "
							+ "from record,computer "
							+ "where record.cno = computer.cno "
							+ "and computer.rno = '"+rno.trim()+"' "
							+ "group by computer.rno");
					boolean x = rs4.next();
					if(!x) {
						textField_income.setText("0");
					}
					
					if(x) {
					textField_income.setText(rs4.getString("income"));
					}
					rs4.close();
					st.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		list_room.setVisibleRowCount(10);
		list_room.setSelectedIndex(0);
		JScrollPane scrollPane = new JScrollPane(list_room);

		JPanel panel_room = new JPanel();
		panel_room.setBounds(10, 62, 149, 180);
		frame.getContentPane().add(panel_room);

		panel_room.add(scrollPane);
		
		JLabel label_3 = new JLabel("\u673A\u5668\u6570\u91CF");
		label_3.setBounds(10, 300, 54, 15);
		frame.getContentPane().add(label_3);
		
		JButton button_new_com = new JButton("\u65B0\u5EFA");
		button_new_com.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				NewCom.go();
			}
		});
		button_new_com.setBounds(345, 62, 93, 23);
		frame.getContentPane().add(button_new_com);
		
		JButton button_mod_com = new JButton("\u4FEE\u6539");
		button_mod_com.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ModCom.go();
			}
		});
		button_mod_com.setBounds(345, 95, 93, 23);
		frame.getContentPane().add(button_mod_com);
		
		JLabel lblIp = new JLabel("ip\u5730\u5740");
		lblIp.setBounds(211, 244, 54, 15);
		frame.getContentPane().add(lblIp);
		
		
		
		JButton button = new JButton("\u5220\u9664");
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					Statement st = Conn.dbconn.createStatement();
					st.execute("delete from computer where cno = '"+Computer.cno+"'");
					JOptionPane.showMessageDialog(button, "ɾ���ɹ���", "��ʾ", JOptionPane.INFORMATION_MESSAGE);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					JOptionPane.showMessageDialog(button, "ɾ��ʧ�ܣ�", "��ʾ", JOptionPane.ERROR_MESSAGE);
					e1.printStackTrace();
				}
				
			}
		});
		button.setBounds(345, 130, 93, 23);
		frame.getContentPane().add(button);
		
		JLabel label_income = new JLabel("\u603B\u6536\u5165");
		label_income.setBounds(10, 356, 54, 15);
		frame.getContentPane().add(label_income);
		
		
		
	}

	public JTextField getTextField_ip() {
		return textField_ip;
	}

	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}

	void setTextField_ip(JTextField textField_ip) {
		this.textField_ip = textField_ip;
	}
}
