package testwindow;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.Toolkit;

public class FuncSelect {

	static JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void go() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FuncSelect window = new FuncSelect();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public FuncSelect() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage(FuncSelect.class.getResource("/testwindow/bg.jpg")));
		frame.setTitle("\u529F\u80FD\u9009\u62E9");
		frame.setBounds(100, 100, 329, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				Conn.close();
			}
		});
		JButton button_stu = new JButton("\u4E0A\u673A\u7BA1\u7406");
		button_stu.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Student.go();
				frame.setVisible(false);
			}
		});
		button_stu.setBounds(96, 50, 116, 41);
		frame.getContentPane().add(button_stu);
		
		JButton button_room = new JButton("\u673A\u623F\u7BA1\u7406");
		button_room.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				Computer.go();
				frame.setVisible(false);
			}
		});
		button_room.setBounds(96, 121, 116, 43);
		frame.getContentPane().add(button_room);
	}
}
