package testwindow;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.eclipse.wb.swing.FocusTraversalOnArray;
import java.awt.Component;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.Color;
import java.awt.Toolkit;
import javax.swing.JPanel;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Login {

	private JFrame frmauthorZx;
	private JTextField textField;
	private JPasswordField passwordField;
	/**
	 * Launch the application.
	 */

	public static void go() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frmauthorZx.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
				
			}
			
		});
	}
	public String login(String sql) {
		String str = "";
		try {
			Statement st = Conn.dbconn.createStatement();
			ResultSet rs = st.executeQuery(sql);
			while(rs.next())
			str +=rs.getString("p");
			rs.close();
			st.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return str;
	}
	/**
	 * Create the application.
	 */
	public Login() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		//established the connection to the database
		
		frmauthorZx = new JFrame();
		frmauthorZx.setIconImage(Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/testwindow/bg.jpg")));
		frmauthorZx.setTitle("\u673A\u623F\u7BA1\u7406\u7CFB\u7EDF(@author ZX)");
		frmauthorZx.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				Conn.close();
			}
		});
		frmauthorZx.setBounds(100, 100, 346, 247);
		frmauthorZx.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmauthorZx.getContentPane().setLayout(null);
		
		JLabel lblUser = new JLabel("user");
		lblUser.setBounds(84, 53, 54, 15);
		frmauthorZx.getContentPane().add(lblUser);
		
		JLabel lblPassword = new JLabel("password");
		lblPassword.setBounds(84, 98, 54, 21);
		frmauthorZx.getContentPane().add(lblPassword);
		
		textField = new JTextField();
		textField.setBounds(155, 50, 93, 21);
		frmauthorZx.getContentPane().add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyChar() == KeyEvent.VK_ENTER) {
					String po = login("select * from admin where u='"+textField.getText()+"'").trim();
					char[] pnt = passwordField.getPassword();
					String pn = new String(pnt).trim();

					if(po.equals(pn)) {
						FuncSelect.go();
						frmauthorZx.dispose();
					}
					else {
						JOptionPane.showMessageDialog(passwordField,"Login Failed!", "��ʾ", JOptionPane.WARNING_MESSAGE);
					}
				}
			}
		});
	
		
		passwordField.setBounds(155, 98, 93, 21);
		frmauthorZx.getContentPane().add(passwordField);
		
		JButton btnLogin = new JButton("login");
		btnLogin.setIcon(null);
		btnLogin.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String po = login("select * from admin where u='"+textField.getText()+"'").trim();
				char[] pnt = passwordField.getPassword();
				String pn = new String(pnt).trim();

				if(po.equals(pn)) {
					FuncSelect.go();
					frmauthorZx.dispose();
				}
				else {
					JOptionPane.showMessageDialog(btnLogin,"Login Failed!", "��ʾ", JOptionPane.WARNING_MESSAGE);
				}
			}
			
		});
		btnLogin.setBounds(122, 146, 93, 23);
		frmauthorZx.getContentPane().add(btnLogin);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 330, 208);
		frmauthorZx.getContentPane().add(panel);
		frmauthorZx.getContentPane().setFocusTraversalPolicy(new FocusTraversalOnArray(new Component[]{textField, passwordField, btnLogin}));
		frmauthorZx.setFocusTraversalPolicy(new FocusTraversalOnArray(new Component[]{textField, passwordField, btnLogin}));
	
	}
}
