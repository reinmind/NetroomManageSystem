package testwindow.comop;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Toolkit;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import testwindow.Conn;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.sql.Statement;

public class NewCom extends JDialog {

	
	private final JPanel contentPanel = new JPanel();
	private JTextField textField_cno;
	private JTextField textField_rno;
	private JTextField textField_ip;
	/**
	 * Launch the application.
	 */
	public static void go() {
		try {
			NewCom dialog = new NewCom();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public NewCom() {
		setTitle("\u65B0\u5EFA");
		setIconImage(Toolkit.getDefaultToolkit().getImage(ModCom.class.getResource("/testwindow/bg.jpg")));
		setBounds(100, 100, 294, 282);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel label = new JLabel("\u7535\u8111\u7F16\u53F7");
			label.setBounds(52, 54, 54, 15);
			contentPanel.add(label);
		}
		{
			textField_cno = new JTextField();
			textField_cno.setBounds(116, 51, 119, 21);
			contentPanel.add(textField_cno);
			textField_cno.setColumns(10);
		}
		{
			JLabel label = new JLabel("\u6240\u5C5E\u673A\u623F");
			label.setBounds(52, 96, 54, 15);
			contentPanel.add(label);
		}
		{
			textField_rno = new JTextField();
			textField_rno.setBounds(116, 93, 119, 21);
			contentPanel.add(textField_rno);
			textField_rno.setColumns(10);
		}
		{
			JLabel lblIp = new JLabel("ip\u5730\u5740");
			lblIp.setBounds(52, 142, 54, 15);
			contentPanel.add(lblIp);
		}
		{
			textField_ip = new JTextField();
			textField_ip.setBounds(116, 139, 119, 21);
			contentPanel.add(textField_ip);
			textField_ip.setColumns(10);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						try {
							String sql;
							sql = "insert into computer(rno,ip,cno) values('"
									+textField_rno.getText().trim()+"','"
									+textField_ip.getText().trim()+"','"
									+textField_cno.getText().trim()+"')";
							Statement st = Conn.dbconn.createStatement();
							st.execute(sql);
							JOptionPane.showMessageDialog(okButton, "�ύ�ɹ���", "��ʾ",JOptionPane.INFORMATION_MESSAGE);
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
		}
	}

}
