package testwindow;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.Dialog.ModalityType;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import org.eclipse.wb.swing.FocusTraversalOnArray;
import java.awt.Component;
import java.awt.Toolkit;

public class ModStu extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField textField_sno;
	private JTextField textField_name;
	private JTextField textField_sex;
	private JTextField textField_dept;
	private JTextField textField_type;
	private JPanel buttonPane;
	private JButton okButton;

	/**
	 * Launch the application.
	 */
	public static void go() {
		try {
			ModStu dialog = new ModStu();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public ModStu() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(ModStu.class.getResource("/testwindow/bg.jpg")));
		
		setModalityType(ModalityType.APPLICATION_MODAL);
		setTitle("\u4FEE\u6539\u5B66\u751F\u4FE1\u606F");
		setBounds(100, 100, 315, 277);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel label = new JLabel("\u7528\u6237\u7C7B\u578B");
			label.setBounds(28, 130, 80, 15);
			contentPanel.add(label);
		}
		{
			JLabel label = new JLabel("\u5B66\u9662");
			label.setBounds(28, 99, 54, 15);
			contentPanel.add(label);
		}
		{
			JLabel label = new JLabel("\u6027\u522B");
			label.setBounds(28, 72, 82, 15);
			contentPanel.add(label);
		}
		{
			JLabel label = new JLabel("\u59D3\u540D");
			label.setBounds(30, 41, 54, 15);
			contentPanel.add(label);
		}
		{
			JLabel label = new JLabel("\u5B66\u53F7");
			label.setBounds(30, 13, 80, 15);
			contentPanel.add(label);
		}
		{
			textField_sno = new JTextField();
			textField_sno.setBounds(120, 10, 116, 21);
			textField_sno.setText("<dynamic>");
			textField_sno.setEditable(false);
			textField_sno.setColumns(10);
			contentPanel.add(textField_sno);
		}
		{
			textField_name = new JTextField();
			textField_name.setBounds(120, 38, 116, 21);
			textField_name.setText("<dynamic>");
			textField_name.setColumns(10);
			contentPanel.add(textField_name);
		}
		{
			textField_sex = new JTextField();
			textField_sex.setBounds(120, 69, 116, 21);
			textField_sex.setText("<dynamic>");
			textField_sex.setColumns(10);
			contentPanel.add(textField_sex);
		}
		{
			textField_dept = new JTextField();
			textField_dept.setBounds(120, 96, 116, 21);
			textField_dept.setText("<dynamic>");
			textField_dept.setColumns(10);
			contentPanel.add(textField_dept);
		}
		{
			textField_type = new JTextField();
			textField_type.setBounds(120, 127, 116, 21);
			textField_type.setText("<dynamic>");
			textField_type.setColumns(10);
			contentPanel.add(textField_type);
		}
		{
			buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				okButton = new JButton("OK");
				okButton.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						String sql = "";
						sql = sql +"update student "
								+ "set sname = "+"'"+textField_name.getText().trim()+"'"
								+ ",sdept = " + "'"+textField_dept.getText().trim()+"'"
								+ ",ssex = " + "'"+textField_sex.getText().trim()+"'"
								+ ",type = " + "'"+textField_type.getText().trim()+"'"
								+ " where sno = " + "'"+textField_sno.getText().trim()+"'";
						try {
							Statement st = Conn.dbconn.createStatement();
							st.executeQuery(sql);
							st.close();
							JOptionPane.showMessageDialog(okButton, "�ύ�ɹ���", "��ʾ", JOptionPane.INFORMATION_MESSAGE);
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							
							if(e1.getErrorCode() == 0)
							JOptionPane.showMessageDialog(okButton, "�ύ�ɹ���", "��ʾ", JOptionPane.INFORMATION_MESSAGE);
							else
								JOptionPane.showMessageDialog(okButton, "�ύʧ�ܣ�", "��ʾ", JOptionPane.ERROR_MESSAGE);
						}
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
		}
		textField_sno.setText(Student.win.getTextField_sno().getText().trim());
		textField_dept.setText(Student.win.getTextField_dept().getText().trim());
		textField_name.setText(Student.win.getTextField_name().getText().trim());
		textField_sex.setText(Student.win.getTextField_sex().getText().trim());
		textField_type.setText(Student.win.getTextField_type().getText().trim());
		setFocusTraversalPolicy(new FocusTraversalOnArray(new Component[]{textField_sno, textField_name, textField_sex, textField_dept, textField_type, buttonPane, okButton}));
	}

}
