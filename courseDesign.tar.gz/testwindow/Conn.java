package testwindow;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Conn {
	public static String url = "jdbc:sqlserver://47.106.76.77:1433;database=newdb";
	public static String driverName = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	public static String userName = "pub";
	public static String passwd = "1234Abcd";
	public static Connection dbconn;
	public static void main(String[] args) {
		Conn conn = new Conn();
		Login.go();
		
	}
	Conn(){
		try {
		Class.forName(driverName);
		dbconn = DriverManager.getConnection(url,userName,passwd);
		System.out.println("Database connect success!");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		}
	public static void close() {
		if(dbconn != null) {
			try {
			dbconn.close();
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		}
		System.out.println("Database connection closed!");
	}
	
	
}

